----------------------------------------------------------------------
purgeLogs: Archive & Cleanup traces, logs in one command (OL7)
Patch 36518442 - PLACEHOLDER FOR purgelogs (Version: 20241002 - Revision: 2.0.1-13)
(OL7 RPM sha256sum: 82b8a8267f6ce7047acc409c2838470936ced3a4b17f324b62eb36c7eac598ef)
 
The user documentation is located at MOS: 'purgeLogs: Archive & Cleanup traces, logs in one command (Doc ID 2081655.1)'
--> https://support.oracle.com/epmos/faces/DocumentDisplay?id=2081655.1

The patch consists of one zip file within an RPM.
----------------------------------------------------------------------
