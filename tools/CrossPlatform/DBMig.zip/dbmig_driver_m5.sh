#!/bin/sh
 
################################################################################
#
# dbmig_driver.sh
#
#===============================================================================
# Last modified : January 26, 2023
# Version       : 4.7
# Purpose       : Script to automate Cross Endian Database Migration
#===============================================================================
#
#  Disclaimer:
#  -----------
#  Although this program has been tested and used successfully, it is not
#  supported by Oracle Support Services.
#  It has been tested internally, and works as documented, however, we do not
#  guarantee that it will work for you, so be sure to test it in your test
#  environment before relying on it. 
#  We do not claim any responsibility for any problems and/or damage caused
#  by this program. This program comes "as is", please use it at your own risk.
#  Due to the differences in the way text editors, e-mail programs and
#  operating systems handle text formatting (spaces, tabs and carriage returns),
#  proofread this script before execution.
#
#  Ver 4.7: Add check_conn
#  Ver 4.6: Add RMAN debug, show all and set NLS_DATE_FORMAT
#           Add FROM SCN to avoid breaking the backup sequence if a backup is taken
#           outside the migration process.
#
#  Ver 4.5: Fix gen_restore to exclude autobackup controlfile from restore script
#           Implement SYSTEM_USR
#           Add password input for EXPDP
#
 
if [ $# -ne 1 ]; then
        echo "Please call this script using the syntax $0 "
        echo "Example: # sh dbmig_driver.sh L0|L1|L1F"
        exit 1
fi
 
 
export CMD_DIR=$PWD/cmd
export NLS_DATE_FORMAT="DD-MM-YYYY HH24:MI:SS"
 
if [ ! -f ${CMD_DIR}/dbmig_driver.properties ]; then
        echo "Properties file not found, exiting. "
        exit 1
        else
        echo "Properties file found, sourcing.";
        . ${CMD_DIR}/dbmig_driver.properties
        export ORACLE_SID
        export ORACLE_HOME
fi
 
 
if [ ! -f ${CMD_DIR}/.next_scn ]; then
        echo "Next SCN file not found, creating it. "
                ${CMD_TOUCH} ${CMD_DIR}/.next_scn
fi
 
if [ ! -f ${CMD_DIR}/dbmig_ts_list.txt ]; then
        echo "Tablespace list not found, exiting. "
                exit 1
fi
 
if [ -d "$LOG_DIR" ] && [ -d "$CMD_DIR" ]; then
  echo "LOG and CMD directories found"
else
  echo "LOG and CMD directories not found, creating"
  ${CMD_MKDIR} -p ${LOG_DIR}
  ${CMD_MKDIR} -p ${CMD_DIR}
fi

if [[ "$BKP_DEST_TYPE" == "DISK" ]]; then
  if [ ! -d "$BKP_DEST_PARM" ]; then
    echo "Backup to disk, creating $BKP_DEST_PARM"
    ${CMD_MKDIR} -p ${BKP_DEST_PARM}
  fi
fi

if [ ! -d "$SOURCE_DPDMP" ]; then
  echo "Path for ${SOURCE_DPDIR} not found, creating"
  ${CMD_MKDIR} -p ${SOURCE_DPDMP}
fi

function gen_pdb_ts_list {
    export TSF=${1}
    export PDB=${2}
 
    # Create or clear the output file
    > ${TSF}.pdb
 
    # Process the tablespaces file and append the pdb name to each
    awk -v PDB="$PDB" 'BEGIN { FS=","; OFS="," } {
        for (i = 1; i <= NF; i++) {
            gsub(/ /, "", $i);  # Remove spaces in each field
            $i = PDB ":" $i;
        }
        print $0;
    }' ${TSF} >> ${TSF}.pdb
    export TSPDB=`${CMD_CAT} ${TSF}.pdb`
    export TSFPDB=${TSF}.pdb
}
while [[ -f ${LOG_DIR}/rman_mig_bkp.lck ]]; do
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Previous RMAN execution lock is still present!! Resolve issue and delete lock file: $LOG_DIR/rman_mig_bkp.lck. Exiting..."
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Previous RMAN execution lock is still present!! Resolve issue and delete lock file: $LOG_DIR/rman_mig_bkp.lck. Exiting..." >> ${LOG_DIR}/rman_mig_bkp.log
exit 1;
done
 
export BKP_LEVEL=${1}
 
function gen_backup {
case ${BKP_DEST_TYPE} in
         "DISK")
                  export FORMAT="'${BKP_DEST_PARM}/${BKP_LEVEL}_%d_%N_%t_%s_%p'"
                  export CMD_FILE=${CMD_DIR}/bkp_${BKP_LEVEL}_${DT}.cmd
                  export TAG=${ORACLE_SID}_${BKP_LEVEL}_${DT}
                  echo "SET ECHO ON;"                                                           > ${CMD_FILE}
                  echo "SHOW ALL;"                                                              >> ${CMD_FILE}
                  case ${BKP_FROM_STDBY} in
                            "0") 
                            echo "ALTER SYSTEM CHECKPOINT GLOBAL;"                                        >> ${CMD_FILE}
                            echo "SELECT checkpoint_change# prev_incr_ckp_scn FROM v\$database;"          >> ${CMD_FILE}
                            ;;
                            "1")
                              case ${MIG_PDB} in
                              "1")
                                echo "SELECT MIN(dfh.checkpoint_change#) prev_incr_ckp_scn FROM v\$datafile_header dfh, v\$pdbs p WHERE dfh.checkpoint_change# != 0 and p.con_id = dfh.con_id and p.name='${PDB_NAME}';"          >> ${CMD_FILE}
                                ;;
                              *)
                                echo "SELECT MIN(checkpoint_change#) prev_incr_ckp_scn FROM v\$datafile_header WHERE checkpoint_change# != 0;"          >> ${CMD_FILE}
                                ;;
                              esac
                            ;;
                  esac         
                  echo "SET EVENT FOR skip_auxiliary_set_tbs TO 1;"                             >> ${CMD_FILE}
                  echo "RUN"                                                                    >> ${CMD_FILE}
                  echo "{"                                                                      >> ${CMD_FILE}
                  for l_parallelism in `seq 1 ${CHN}`
                  do
                       echo "ALLOCATE CHANNEL d${l_parallelism} DEVICE TYPE ${BKP_DEST_TYPE} FORMAT ${FORMAT};" >> ${CMD_FILE}
                  done
                  echo "BACKUP "                                                                 >> ${CMD_FILE}
                  echo "       FILESPERSET 1"                                                    >> ${CMD_FILE}
                  case ${BKP_LEVEL} in
                            "L1"|"L1F") 
                                echo "       INCREMENTAL FROM SCN ${SCN}"                        >> ${CMD_FILE}
                            ;;
                  esac         
                  echo "       SECTION SIZE ${SECTION_SIZE}                    "                 >> ${CMD_FILE}
                  echo "       TAG ${TAG}"                                                       >> ${CMD_FILE}
                  case ${MIG_PDB} in
                            "0") 
                                echo "       TABLESPACE ${TS};"                                  >> ${CMD_FILE}
                            ;;
                            "1")
                                gen_pdb_ts_list ${TSF} ${PDB_NAME}
                                echo "       TABLESPACE ${TSPDB};"                               >> ${CMD_FILE}
                            ;;
                  esac         
                  echo "}"                                                                       >> ${CMD_FILE}
                                 
          ;;
         "SBT_TAPE")
                  export FORMAT="${BKP_DEST_PARM}"
                  export CMD_FILE=${CMD_DIR}/bkp_${BKP_LEVEL}_${DT}.cmd
                  export TAG=${ORACLE_SID}_${BKP_LEVEL}_${DT}
                  echo "SET ECHO ON;"                                                           > ${CMD_FILE}
                  echo "SHOW ALL;"                                                              >> ${CMD_FILE}
                  case ${BKP_FROM_STDBY} in
                            "0") 
                            echo "ALTER SYSTEM CHECKPOINT GLOBAL;"                                        >> ${CMD_FILE}
                            echo "SELECT checkpoint_change# prev_incr_ckp_scn FROM v\$database;"          >> ${CMD_FILE}
                            ;;
                            "1")                             
                            case ${MIG_PDB} in
                              "1")
                                echo "SELECT MIN(dfh.checkpoint_change#) prev_incr_ckp_scn FROM v\$datafile_header dfh, v\$pdbs p WHERE dfh.checkpoint_change# != 0 and p.con_id = dfh.con_id and p.name='${PDB_NAME}';"          >> ${CMD_FILE}
                                ;;
                              *)
                                echo "SELECT MIN(checkpoint_change#) prev_incr_ckp_scn FROM v\$datafile_header WHERE checkpoint_change# != 0;"          >> ${CMD_FILE}
                                ;;
                              esac
                            ;;
                  esac        
                  echo "SET EVENT FOR skip_auxiliary_set_tbs TO 1;"                             >> ${CMD_FILE}
                  echo "RUN"                                                                    >> ${CMD_FILE}
                  echo "{"                                                                      >> ${CMD_FILE}
                  for l_parallelism in `seq 1 ${CHN}`
                  do
                       echo "ALLOCATE CHANNEL T${l_parallelism} DEVICE TYPE ${BKP_DEST_TYPE} FORMAT ${FORMAT};" >> ${CMD_FILE}
                  done
                  echo "BACKUP "                                                                 >> ${CMD_FILE}
                  echo "       FILESPERSET 1"                                                    >> ${CMD_FILE}
                  case ${BKP_LEVEL} in
                            "L1"|"L1F") 
                                echo "       INCREMENTAL FROM SCN ${SCN}"                        >> ${CMD_FILE}
                            ;;
                  esac         
                  echo "       SECTION SIZE ${SECTION_SIZE}                    "                 >> ${CMD_FILE}
                  echo "       TAG ${TAG}"                                                       >> ${CMD_FILE}
                  case ${MIG_PDB} in
                            "0") 
                                echo "       TABLESPACE ${TS};"                                  >> ${CMD_FILE}
                            ;;
                            "1")
                                gen_pdb_ts_list ${TSF} ${PDB_NAME}
                                echo "       TABLESPACE ${TSPDB};"                               >> ${CMD_FILE}
                            ;;
                  esac         
                  echo "}"                                                                       >> ${CMD_FILE}
                  export FORMAT=`echo $BKP_DEST_PARM | sed 's+"+\\\\"+g'`
         ;;
             *)
 
         ;;
esac
}
 
function chk_backup {
export BKP_ERR=`egrep "WARN-|ORA-" ${BKP_LOG} | wc -l`
if [ "${BKP_ERR}" != 0 ];
  then
    echo ""
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Found errors or warnings in backup log file ${BKP_LOG} for pid $$ Aborting..."
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Found errors or warnings in backup log file ${BKP_LOG} for pid $$ Aborting..." >> ${LOG_DIR}/chk_backup.log
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Found errors or warnings in backup log file ${BKP_LOG} for pid $$ Aborting..." >> ${LOG_DIR}/rman_mig_bkp.log
    echo "${BKP_ERR}" >> ${LOG_DIR}/chk_backup.log
    exit 1
  else
    echo ""
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: No errors or warnings found in backup log file for pid $$"
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: No errors or warnings found in backup log file for pid $$" >> ${LOG_DIR}/chk_backup.log
    echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: No errors or warnings found in backup log file for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
fi
 
}
 
function check_conn {
connection_string="${1}/${2}${3}"
 
sqlplus -s $connection_string << EOF
  set feedback off
  set heading off
  select 'Connected successfully' from dual;
  exit;
EOF
 
if [ $? -eq 0 ]; then
  echo "Oracle authentication successful"
else
  echo "Oracle authentication failed"
  exit 1
fi
}
 
 
function gen_restore {
export BKP_LOG=${1}
export RES_CMD=${CMD_DIR}/restore_${BKP_LEVEL}_${ORACLE_SID}_${DT}.cmd
export RES_LOG=restore_${BKP_LEVEL}_${ORACLE_SID}_${DT}.log
export RES_TRC=restore_${BKP_LEVEL}_${ORACLE_SID}_${DT}.trc
export GEN_CMD="${WORKDIR}/gen_restore_cmd.awk"
cat << EOF > ${GEN_CMD}
BEGIN {
   print "SPOOL LOG TO log/${RES_LOG};"
   print "SPOOL TRACE TO log/${RES_TRC};"
   print "SET EVENT FOR catalog_foreign_datafile_restore TO 1;"
   print "SET ECHO ON;"
   print "SHOW ALL;"
   print "DEBUG ON;"
   print "RUN"
   print "{"
   for (i = 1; i <= ${CHN}; i++)
       {
         channel_string = "ALLOCATE CHANNEL ${BKP_DEST_TYPE}"i" DEVICE TYPE ${BKP_DEST_TYPE} FORMAT ${FORMAT};"
         print channel_string;
       }
   print "RESTORE ALL FOREIGN DATAFILES TO NEW FROM BACKUPSET"
}
/piece handle=/ && !/autobackup/ && !/AUTOBACKUP/{
  split(\$3, a, "=");
  q="'";
  printf("%s%s%s%s",sep,q,a[2],q);
  sep=",\n";
}
END {
  print ";}"
}
EOF
${CMD_AWK} -f ${GEN_CMD} ${BKP_LOG} > ${RES_CMD}
if [[ -n "${DEST_SERVER}" ]]; then
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Transferring restore script for pid $$ to destination"
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Transferring restore script for pid $$ to destination" >> ${LOG_DIR}/rman_mig_bkp.log
  ${CMD_SCP} ${RES_CMD} ${DEST_USER}\@${DEST_SERVER}:${DEST_WORKDIR}
  
else
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Manually copy restore script to destination"
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`:  => $RES_CMD"
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Manually copy restore script to destination" >> ${LOG_DIR}/rman_mig_bkp.log
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`:  => $RES_CMD" >> ${LOG_DIR}/rman_mig_bkp.log
fi
}
 
function run_conv_stby {
export role=${1}
echo ${role}
${ORACLE_HOME}/bin/dgmgrl << EOF
connect / as sysdba
show configuration
convert database ${ORACLE_SID} to ${role} standby;
show configuration
exit
EOF
}
 
function run_ts_ro {
export TSF=${1}
${CMD_AWK} -F',' 'BEGIN {i=0} {for (i=1;i<=NF;i++) print "ALTER TABLESPACE " $i " READ ONLY;"}' ${TSF} |tr -d '"' > ${CMD_DIR}/dbmig_ts_ro.sql
${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
connect  ${SYSTEM_USR}/${2}${SRC_SCAN}
spool ${CMD_DIR}/dbmig_ts_ro.lst
@ ${CMD_DIR}/dbmig_ts_ro.sql
exit
EOF
}
 
function bkp_report {
${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
connect / as sysdba
SET LINESIZE 333 TERMOUT OFF FEEDBACK OFF
COL BACKUP_TYPE FOR A20
spool ${CMD_DIR}/bkp_report.lst
SELECT input_type "BACKUP_TYPE"
     , NVL(input_bytes/(1024*1024),0)"INPUT_BYTES(MB)"
     , NVL(output_bytes/(1024*1024),0) "OUTPUT_BYTES(MB)"
     , status
     , TO_CHAR(start_time,'MM/DD/YYYY:hh24:mi:ss') as START_TIME
     , TO_CHAR(end_time,'MM/DD/YYYY:hh24:mi:ss') as END_TIME
     , TRUNC((elapsed_seconds/60),2) "ELAPSED_TIME(Min)"
  FROM v\$rman_backup_job_details
WHERE session_key = (SELECT MAX(session_key)
                        FROM v\$rman_backup_job_details)
ORDER BY END_TIME DESC;
EXIT
EOF
cat ${CMD_DIR}/bkp_report.lst >> ${LOG_DIR}/rman_mig_bkp.log
}
 
function gen_expdp {
export EXP_PAR=${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par
echo "USERID='${SYSTEM_USR}/${1}${SRC_SCAN}'" > ${EXP_PAR}
echo "DUMPFILE=exp_${ORACLE_SID}_${DT}.dmp" >> ${EXP_PAR}
echo "DIRECTORY=${SOURCE_DPDIR}" >> ${EXP_PAR}
echo "LOGFILE=exp_${ORACLE_SID}.log" >> ${EXP_PAR}
echo "REUSE_DUMPFILES=y" >> ${EXP_PAR}
echo "TRANSPORTABLE=ALWAYS" >> ${EXP_PAR}
echo "LOGTIME=ALL" >> ${EXP_PAR}
echo "METRICS=Y" >> ${EXP_PAR}
echo "FULL=Y" >> ${EXP_PAR}
echo "EXCLUDE = STATISTICS" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'DOH%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'SA%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'MM%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'AP%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'PS%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'SO%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'NJ%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'AB%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'RM%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'SC%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'TB%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'USERS%\'\"" >> ${EXP_PAR}
echo "EXCLUDE = TABLESPACE:\"LIKE \'TEST%\'\"" >> ${EXP_PAR}
echo "TRACE=${DP_TRACE}" >> ${EXP_PAR}
echo "PARALLEL=${DP_PARALLEL}" >> ${EXP_PAR}
if [[ "$DP_ENC_PROMPT" == "Y" ]]; then
  echo "ENCRYPTION_PWD_PROMPT=YES" >> ${EXP_PAR}
fi  
}
 
function run_expdp {
${ORACLE_HOME}/bin/expdp parfile=${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par

if [[ -n "${DEST_SERVER}" ]]; then
  #scp to destination
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Transferring Data Pump dump file to destination"
  ${CMD_SCP} ${SOURCE_DPDMP}/exp_${ORACLE_SID}_${DT}.dmp ${DEST_USER}\@${DEST_SERVER}:${DEST_DPDMP}
else
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Manually copy Data Pump dump file to destination"
  echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`:  => $SOURCE_DPDMP/exp_$ORACLE_SID_$DT.dmp"
fi

}
 
 
function run_backup {
export BKP_LOG=${LOG_DIR}/bkp_${BKP_LEVEL}_${CHN}CH_${SECTION_SIZE}_${ORACLE_SID}_${DT}.log
export TRC_LOG=${LOG_DIR}/bkp_${BKP_LEVEL}_${CHN}CH_${SECTION_SIZE}_${ORACLE_SID}_${DT}.trc
case ${BKP_LEVEL} in
          "L1F")
              echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Executing final backup iteration for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
              case ${BKP_DEST_TYPE} in
                        "DISK") 
                              case ${BKP_FROM_STDBY} in
                                        "0") 
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Switching migrated tablespaces to read-only pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "============================================"
                                          echo "Enter the system password to perform read only tablespaces"
                                          stty -echo
                                          read system_pw
                                          stty echo
                                          check_conn ${SYSTEM_USR} ${system_pw} ${SRC_SCAN}
                                          run_ts_ro ${TSF} ${system_pw}
                                          ${ORACLE_HOME}/bin/rman target / log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          chk_backup ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          gen_restore ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating export datapump parfile for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                   
                                          gen_expdp ${system_pw}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated export datapump parfile ${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Running export datapump for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_expdp >> ${LOG_DIR}/rman_mig_bkp.log
                                        ;;
                                        "1")                             
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Converting Standby to Snapshot for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_conv_stby "snapshot"
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Switching migrated tablespaces to read-only pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "============================================"
                                          echo "Enter the system password to perform read only tablespaces and export data pump"
                                          stty -echo
                                          read system_pw
                                          stty echo
                                          run_ts_ro ${TSF} ${system_pw}
                                          check_conn ${SYSTEM_USR} ${system_pw} ${SRC_SCAN}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Executing Backup pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          ${ORACLE_HOME}/bin/rman target / log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating export datapump parfile for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                   
                                          gen_expdp ${system_pw}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated export datapump parfile ${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Running export datapump for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_expdp >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          chk_backup ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          gen_restore ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Converting Standby to Physical for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                                         
                                          run_conv_stby "physical"
                                        ;;
                              esac         
                          ;;
                        "SBT_TAPE")
                              case ${BKP_FROM_STDBY} in
                                        "0") 
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Switching migrated tablespaces to read-only pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "============================================"
                                          echo "Enter the system password to perform read only tablespaces and export data pump"
                                          stty -echo
                                          read system_pw
                                          stty echo
                                          check_conn ${SYSTEM_USR} ${system_pw} ${SRC_SCAN}
                                          run_ts_ro ${TSF} ${system_pw}
                                          ${ORACLE_HOME}/bin/rman target / catalog /\@${CAT_CRED} log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          chk_backup ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          gen_restore ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating export datapump parfile for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                   
                                          gen_expdp ${system_pw}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated export datapump parfile ${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Running export datapump for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_expdp >> ${LOG_DIR}/rman_mig_bkp.log
                                        ;;
                                        "1")   
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Converting Standby to Snapshot for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_conv_stby "snapshot"   
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Switching migrated tablespaces to read-only pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "============================================"
                                          echo "Enter the system password to perform read only tablespaces"
                                          stty -echo
                                          read system_pw
                                          stty echo
                                          check_conn ${SYSTEM_USR} ${system_pw} ${SRC_SCAN}
                                          run_ts_ro ${TSF} ${system_pw}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Executing Backup pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          ${ORACLE_HOME}/bin/rman target / catalog /\@${CAT_CRED} log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating export datapump parfile for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          gen_expdp ${system_pw}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated export datapump parfile ${CMD_DIR}/exp_${ORACLE_SID}_${DT}_xtts.par for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Running export datapump for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          run_expdp >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          chk_backup ${BKP_LOG}                                         
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          gen_restore ${BKP_LOG}
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                                          echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Converting Standby to Physical for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                                          
                                          run_conv_stby "physical"
                                        ;;
                              esac                       
                          ;;               
              esac
           ;; 
          "L0"|"L1")
                echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Executing backup iteration log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                case ${BKP_DEST_TYPE} in
                "DISK")
                      ${ORACLE_HOME}/bin/rman target / log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      chk_backup ${BKP_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log                   
                      gen_restore ${BKP_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Saving SCN for next backup for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Saving SCN for next backup for pid $$"
                      ${CMD_CAT} ${BKP_LOG} | ${CMD_GREP} PREV -A2 | awk 'NR==3' | awk -F':' '{print $2}' | sed 's/ //g' > ${CMD_DIR}/.next_scn
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: SCN taken before backup in logfile ${BKP_LOG} is: `${CMD_CAT} ${BKP_LOG} | ${CMD_GREP} PREV -A2 | awk 'NR==3' | awk -F':' '{print $2}' | sed 's/ //g'`" >> ${CMD_DIR}/.next_scn_hist                   
                  ;;
                "SBT_TAPE")
                      ${ORACLE_HOME}/bin/rman target / catalog /\@${CAT_CRED} log=${BKP_LOG} cmdfile=${CMD_FILE} debug trace=${TRC_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Checking backup log for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      chk_backup ${BKP_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating restore command ${RES_CMD} for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      gen_restore ${BKP_LOG}
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generated restore command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Saving SCN for next backup for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Saving SCN for next backup for pid $$"
                      ${CMD_CAT} ${BKP_LOG} | ${CMD_GREP} PREV -A2 | awk 'NR==3'| awk -F':' '{print $2}' | sed 's/ //g' > ${CMD_DIR}/.next_scn
                      echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: SCN taken before backup in logfile ${BKP_LOG} is: `${CMD_CAT} ${BKP_LOG} | ${CMD_GREP} PREV -A2 | awk 'NR==3' | awk -F':' '{print $2}' | sed 's/ //g'`" >> ${CMD_DIR}/.next_scn_hist                   
                  ;;
      esac
esac
}
 
echo "=========================================================================================================" >> ${LOG_DIR}/rman_mig_bkp.log
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: No active previous RMAN execution, touching lock file and running DB backup for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
${CMD_TOUCH} ${LOG_DIR}/rman_mig_bkp.lck
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Requested ${BKP_LEVEL} backup for pid $$.  Using ${BKP_DEST_TYPE} destination, ${CHN} channels and ${SECTION_SIZE}${SECTION_SIZE_UNIT} section size."
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Requested ${BKP_LEVEL} backup for pid $$.  Using ${BKP_DEST_TYPE} destination, ${CHN} channels with ${SECTION_SIZE}${SECTION_SIZE_UNIT} section size." >> ${LOG_DIR}/rman_mig_bkp.log
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Performing ${BKP_LEVEL} backup for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Performing ${BKP_LEVEL} backup for pid $$"
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Generating backup script for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
gen_backup
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Executing backup routine command for pid $$" >> ${LOG_DIR}/rman_mig_bkp.log
run_backup
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Backup log is: ${BKP_LOG}" >> ${LOG_DIR}/rman_mig_bkp.log
echo "`date +%Y-%m-%d\ %H:%M:%S` - `date +%s%3N`: Restore command is: ${RES_CMD}" >> ${LOG_DIR}/rman_mig_bkp.log
bkp_report
${CMD_RM} ${LOG_DIR}/rman_mig_bkp.lck
