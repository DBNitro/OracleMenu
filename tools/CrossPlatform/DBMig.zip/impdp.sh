#!/bin/bash
 
if [ $# -ne 4 ]; then
        echo "Please call this script using the syntax $0 "
        echo "Example: # sh impdp.sh <expdp_dumpfile> <rman_last_restore_log> [run|test|run-readonly|test-readonly] <encryption_pwd_prompt[Y|N]>"
        exit 1
fi

#Full path to Oracle Home
export ORACLE_HOME=/u01/app/oracle/product/19.0.0.0/dbhome_13
export PATH=$PATH:$ORACLE_HOME/bin
#SID of the destination database
export ORACLE_SID=<MYSID>
#Connect string to destination database. If PDB, connect directly into PDB
export ORACLE_CONNECT_STRING=<MYCONNECTSTRING>
#Data Pump directory
export DATA_PUMP_DIR=DATA_PUMP_DIR
#Data Pump parallel setting
export DATA_PUMP_PARALLEL=1
#Data Pump trace level. 0 to disable. 3FF0300 for transportable tablespace trace
export DATA_PUMP_TRACE=0

############################################################
#Normally, do not edit below this line
############################################################

export PATH=$PATH:$ORACLE_HOME/bin
export DT=`date +%y%m%d%H%M%S`
export EXPDP_DMP=${1}
export RES_LOG=${2}
export RUN_MODE=${3}
export DP_ENC_PROMPT=${4}
 
echo "userid='system@${ORACLE_CONNECT_STRING}'" > imp_${ORACLE_SID}_${DT}_xtts.par
echo "dumpfile=${EXPDP_DMP}" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "directory=${DATA_PUMP_DIR}" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "LOGTIME=ALL" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "TRACE=${DATA_PUMP_TRACE}" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "PARALLEL=${DATA_PUMP_PARALLEL}" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "LOGFILE=imp_${ORACLE_SID}_${DT}_xtts.log" >> imp_${ORACLE_SID}_${DT}_xtts.par
echo "METRICS=YES" >> imp_${ORACLE_SID}_${DT}_xtts.par
case ${DP_ENC_PROMPT} in
     "Y")
        echo "ENCRYPTION_PWD_PROMPT=YES" >> imp_${ORACLE_SID}_${DT}_xtts.par
       ;;
     "N")
        echo "ENCRYPTION_PWD_PROMPT=NO" >> imp_${ORACLE_SID}_${DT}_xtts.par
      ;;
      *)
      ;;      
esac
echo "TRANSPORT_DATAFILES=" >> imp_${ORACLE_SID}_${DT}_xtts.par
 
# Run your grep command and store the output in the input variable
input=$(grep "restoring foreign" ${RES_LOG} | awk '{print $9}' | sort |  uniq)
 
# Read the input into an array, splitting on newline
IFS=$'\n' read -rd '' -a input_list <<< "$input"
 
output_list=()
 
for item in "${input_list[@]}"; do
    output_list+=("'$item',")
done
 
# Remove the trailing comma from the last line
last_index=$(( ${#output_list[@]} - 1 ))
output_list["$last_index"]="${output_list[last_index]%,}"
 
for item in "${output_list[@]}"; do
    echo "$item" >> imp_${ORACLE_SID}_${DT}_xtts.par
done
 
 
function gen_grp {
${ORACLE_HOME}/bin/sqlplus -s /nolog << EOF
                connect / as sysdba
                set lines 333
                col time for a48
                col restore_point_time for a24
                col name for a24
                spool ${PWD}/dbmig_grp.lst
                create restore point before_imp_${DT} guarantee flashback database;
                select NAME, SCN, TIME, GUARANTEE_FLASHBACK_DATABASE, STORAGE_SIZE FROM V\$RESTORE_POINT WHERE GUARANTEE_FLASHBACK_DATABASE='YES';
                spool off;
                exit
EOF
}
 
case ${RUN_MODE} in
              "run")
                echo "Running in Run mode"
                gen_grp 
                impdp parfile=imp_${ORACLE_SID}_${DT}_xtts.par
              ;;
              "run-readonly")                             
                echo "Running in Read Only, for the final run you must flashback the database to the restore point created now"
                gen_grp
                awk 'NR==3 {print "TRANSPORTABLE=KEEP_READ_ONLY"} {print}' imp_${ORACLE_SID}_${DT}_xtts.par > tmp_file && mv tmp_file imp_${ORACLE_SID}_${DT}_xtts.par
                impdp parfile=imp_${ORACLE_SID}_${DT}_xtts.par
              ;;
              "test")                             
                echo "Running in test mode, check par file for correctness"
              ;;
              "test-readonly")                             
                echo "Running in test mode with read only, check par file for correctness"
                awk 'NR==3 {print "TRANSPORTABLE=KEEP_READ_ONLY"} {print}' imp_${ORACLE_SID}_${DT}_xtts.par > tmp_file && mv tmp_file imp_${ORACLE_SID}_${DT}_xtts.par
              ;;                         
              *)
                echo "Unknown run mode, options are: run, test, run-readonly, test-readonly"
esac
